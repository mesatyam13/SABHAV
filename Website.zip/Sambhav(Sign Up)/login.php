<?php
session_start();
error_reporting(0);
include('includes/config.php');
if($_SESSION['login']!=''){
$_SESSION['login']='';
}
if(isset($_POST['login']))
{

     $email=$_POST['emailid'];
     $password=md5($_POST['password']);
     $sql ="SELECT studentid,status,rcategory,id FROM information WHERE emailid=:email and password=:password";
     $query= $dbh -> prepare($sql);
     $query-> bindParam(':email', $email, PDO::PARAM_STR);
     $query-> bindParam(':password', $password, PDO::PARAM_STR);
     $query-> execute();
     $results=$query->fetchAll(PDO::FETCH_OBJ);
     if($query->rowCount() > 0)
     {
        foreach ($results as $result)
         {
           $rcat=$result->rcategory;
           $_SESSION['stdid']=$result->studentid;
           $_SESSION['oid']=$result->id;
           if($result->status==1)
           {
             if($result->rcategory==2)
             {
              $_SESSION['ologin']=$_POST['emailid'];;
              echo "<script type='text/javascript'> document.location ='owner/dashboard.php'; </script>";
             }
             if($result->rcategory==1)
             {
              $_SESSION['ulogin']=$_POST['emailid'];;
              echo "<script type='text/javascript'> document.location ='users/dashboard.php'; </script>";
             }
             
             $_SESSION['login']=$_POST['emailid'];
             echo "<script type='text/javascript'> document.location ='signup.php'; </script>";
            }
            else
             {
               echo "<script>alert('Your Account Has been blocked .Please contact admin');</script>";

             }
          }
      } 
      else
      {
        echo "<script>alert('Invalid Details');</script>";
      }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <?php include('includes/links.php'); ?>

</head>
<body>
<?php include('includes/header.php') ?>
<div class="content-wrapper">
<div class="container ">
<div class="row pad-botm">
<div class="col-md-12">
<h4 class="header-line text-center">LOGIN FORM</h4>
</div>
</div>
             
<!--LOGIN PANEL START-->           
<div class="row">
<div class="col-md-3 col-sm-3 col-xs-0 col-md-offset-3" ></div>
<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3" >
<div class="panel panel-info">
<div class="panel-heading"></div>
<div class="panel-body bg-light mr-auto">
<div class="col-md-12 col-sm-12 col-md-offset-3 text-center" >
    <img src="logo.jpeg" >
</div>
<form role="form" method="post">
<div class="form-group ">
<label>Enter Email id</label>
<input class="form-control" type="text" name="emailid" required autocomplete="off" />
</div>
<div class="form-group">
<label>Password</label>
<input class="form-control" type="password" name="password" required autocomplete="off"  />
<p class="help-block"><a href="user-forgot-password.php">Forgot Password</a></p>
</div>
<div class="text-center">
 <button type="submit" name="login" class="btn btn-info ">LOGIN </button> | <a href="signup.php" >Not Register Yet</a>
</div>
</form>

 </div>
</div>
</div>
</div> 
<br> 
<!---LOGIN PABNEL END-->            
             
 
    </div>
    <?php include('includes/footer2.php'); ?>
     <?php include('includes/footer.php'); ?>

    </div>

</body>
</html>
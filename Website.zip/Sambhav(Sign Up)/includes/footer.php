
        <div class="container">
           <div class="row clearfix bg-primary">
                <div class="col-sm-5 copyRight">
                   <p class="text-white" >© 2020 Copyright roomdhundhoo.com, Muzaffarpur</a></p>
                </div>
                <div class="col-sm-3 col-xs-12 privacy_policy text-center"> 
                   <a href="contact.php" style="color: #fff;">Contact us</a> |
                   <a href="#" style="color: #fff;">Privacy Policy</a>
                </div>

                <div class="col-sm-4 col-xs-12  text-center"> 
                   <a href="https://www.facebook.com/RoomdhundhooCom-103054661334768/" class="text-white"><i class="fa fa-facebook" aria-hidden="true"></i></a> |
                   <a href="https://instagram.com/roomdhundhoo_com?igshid=9ur9bf7syqi8" class="text-white"><i class="fa fa-instagram" aria-hidden="true"></i></a> |
                   <a href="#"" class="text-white"><i class="fa fa-twitter" aria-hidden="true"></i></a> |
                   <a href="#"" class="text-white"><i class="fa fa-instagram" aria-hidden="true"></i></a> |
                   <a href="#"" class="text-white"><i class="fa fa-youtube" aria-hidden="true"></i></a>
                </div>

                <div class="text-center bg-dark col-sm-12"> 
                <span style="font-size: 11px; color: #666;"> Designed and Developed by
                  <strong><a href="#" style="color: #777;" target="_blank">UM Services </a></strong>
                  and <a href="#" style="color: #777;">
                     <abbr title="UM Training center, Muzaffarpur ,Mobile No:-8873786027">BHUSHAN</abbr>
                    </a> 
                </span>
            </div>
            
            </div>
        </div>


<section class="footer-section">
<div class="container">
<div class="row foot">

  <div class="col-sm-2"> 

      <div class="card">
      <div class="panel panel-default">
          <div class="panel-heading"><h5 class="card-title text-center">Quick Link</h5> </div>
        <div class="panel-body">  
      <div class="card-body">    
        <div class="row "><a  href="#">Home</a></div> 
        <div class="row "><a   href="#">About</a></div>
        <div class="row "><a   href="#">accommodation </a></div>
        <div class="row "><a  href="#">Terms & condtions</a></div>
        <div class="row "><a  href="#">FAQ's</a></div>     
        </div>
    </div>
    </div>
    </div>
  </div>
  <div class="col-sm-2">
    <div class="card">
    <div class="panel panel-default">
          <div class="panel-heading"> <h5 class="card-title text-center">Our services</h5></div>
        <div class="panel-body">
      <div class="card-body">
        <div class="row"><a href="#">Rooms</a></div>
        <div class="row"><a href="#">Lodge</a></div>
        <div class="row"><a href="#">Flat</a></div>
        <div class="row"><a href="#">Modern room & kitchen</a></div>
        <div class="row"><a href="#"></a></div>
      </div>
    </div>
  </div>      </div>
    </div>

  <div class="col-sm-4">
    <div class="card">      <div class="panel panel-default">
          <div class="panel-heading"><h5 class="card-title text-center">Contact</h5> </div>
        <div class="panel-body">
      <div class="card-body">
        <div class="row"> <i class="fa fa-globe"></i> <strong>Website:- </strong><a href="#">RoomDhundhoo.com</a></div>
        <div class="row"><i class="fa fa-phone"></i><a href="#"> 8507693746</a></div>
        <div class="row"><i class="fa fa-envalope"></i><a href="#">roomdhoundhoo@gmail.com</a></div>
        <div class="row"><i class="fa fa-facebook-f" style="color:green;"></i><a href="https://www.facebook.com/RoomdhundhooCom-103054661334768/"> facebook</a></div>
        <div class="row">2020.<a href="#">RoomDundhoo.com</a></div>
      </div>
    </div>
  </div> 
    </div>
  </div>
  <div class="col-sm-4">
    <div class="card">
    <div class="panel panel-default">
          <div class="panel-heading">       <h5 class="card-title text-center"><i class="fa fa-credit-card" aria-hidden="true"></i>Payment accepted</h5></div>
        <div class="panel-body">
      <div class="card-body">

 
        <div class="row">
          <div class="col-sm-3"><a class="btn btn-primary" href="#"><i class='fab fa-amazon-pay'></i>Phone pay</a></div>
          <div class="col-sm-3"><a class="btn btn-success" href="#"><i class='fab fa-amazon-pay'></i>Google Pay</a></div>
          <div class="col-sm-3"><a class="btn btn-primary" href="#"><i class='fab fa-amazon-pay'></i>Paytm     _</a></div>
         </div>
         <p class="card-text">state bank of India</p>
        <p class="card-text">A/C:-</p>
        <p class="card-text">IFSC CODE:-</p>
        
        </div>

  </div>
  </div>
</div>
</div>
</section>
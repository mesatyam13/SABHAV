    <nav class="navbar navbar-expand-sm bg-primary navbar-dark sticky-top">

<a class="navbar-brand" href="#">
    <img src="logo.jpeg" width="30" height="30" class="d-inline-block align-top" alt="">
     Room Dhundho
  </a>

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
  <ul class="navbar-nav  ml-auto">

                <li class="nav-item">
                  <a class="nav-link text-white" href="signup.php"><span class = "glyphicon glyphicon-log-in"></span> Sign Up</a>
              </li>
              <li class="nav-item">
                  <a class="nav-link text-white" href="login.php"><span class = "glyphicon glyphicon-log-in"></span>User Login</a>
              </li>
              <li class="nav-item">
                  <a class="nav-link text-white" href="adminlogin.php"><span class = "glyphicon glyphicon-log-in"></span>Admin Login</a>
              </li>
              <li class="nav-item">
              <li class="nav-item "><a href = "contact.php" class="nav-link text-white"><span class = "glyphicon "></span> Contact Us</a></li>
              </li>
                </ul>
                <form class="form-inline my-2 my-lg-0">
          <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-success btn-danger my-2 my-sm-0 text-white" type="submit">Search</button>
        </form>
        
  </div>
</nav>  
<?php 
session_start();
include('includes/config.php');
error_reporting(0);
if(isset($_POST['signup']))
{
   $count_my_page =("studentid.txt");
   $hits = file($count_my_page);
   $hits[0] ++;
   $fp = fopen($count_my_page , "w");
   fputs($fp , "$hits[0]");
   fclose($fp); 
   $StudentId= $hits[0]; 
   $fname=$_POST['fullanme'];
   $mobileno=$_POST['mobileno'];
   $email=$_POST['email']; 
   $password=md5($_POST['password']);
   $rrfeature=$_POST['rfeature'] ;
      //user photo validation start
      $_SESSION['rerror']=$_SESSION['berror']=$_SESSION['cerror']="";
      $rfile_name = $_FILES['uimage']['name'];
      $rfile_size =$_FILES['uimage']['size'];
      $rfile_tmp =$_FILES['uimage']['tmp_name'];
      $rfile_type=$_FILES['uimage']['type'];
      $rfile_ext=strtolower(end(explode('.',$_FILES['uimage']['name'])));
      
      $extensions= array("jpeg","jpg","png");
      //message for file success or fail start  
      if(in_array($rfile_ext,$extensions)=== false){
         $_SESSION['rerror']="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($rfile_size > 2097152){
         $_SESSION['rerror']='File size must be excately 2 MB';
      }
      //message for file success or fail   end    
   //user photo validation end
   if(empty($rerrors)==true && empty($berrors)==true && empty($cerrors)==true){
    move_uploaded_file($rfile_tmp,"images/".$rfile_name);
   $status=1;
   $sql="INSERT INTO  information(studentid,fullname,mobileno,emailid,password,status,rcategory,uimage) 
   VALUES(:StudentId,:fname,:mobileno,:email,:password,:status,:rrfeature,:rfile_name)";
   $query = $dbh->prepare($sql);
   $query->bindParam(':StudentId',$StudentId,PDO::PARAM_STR);
   $query->bindParam(':fname',$fname,PDO::PARAM_STR);
   $query->bindParam(':mobileno',$mobileno,PDO::PARAM_STR);
   $query->bindParam(':email',$email,PDO::PARAM_STR);
    $query->bindParam(':password',$password,PDO::PARAM_STR);
   $query->bindParam(':status',$status,PDO::PARAM_STR);   
   $query->bindParam(':rrfeature',$rrfeature,PDO::PARAM_STR);
   $query->bindParam(':rfile_name',$rfile_name,PDO::PARAM_STR);  
   $query->execute();
   $lastInsertId = $dbh->lastInsertId();
   if($lastInsertId)
   {
     echo '<script>alert("Your Registration successfull and your  id is  "+"'.$StudentId.'")</script>';
   }
   else 
   {
       echo "<script>alert('Something went wrong. Please try again');</script>";
   } 
  }else{
    header("location:signup.php");
 }
}

?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup</title>
    <?php include('includes/links.php'); ?>
    <link href="loginstyle.css" rel="stylesheet" />
<script type="text/javascript">
  function valid()
 {
   if(document.signup.password.value!= document.signup.confirmpassword.value)
   {
     alert("Password and Confirm Password Field do not match  !!");
     document.signup.confirmpassword.focus();
     return false;
    }
    return true;
  }
</script>
<script>
  function checkAvailability() {
  $("#loaderIcon").show();
  jQuery.ajax({
  url: "check_availability.php",
  data:'emailid='+$("#emailid").val(),
  type: "POST",
  success:function(data)
  {
    $("#user-availability-status").html(data);
    $("#loaderIcon").hide();
  },
  error:function (){}
  });
  }
</script> 
</head>
<body>
<?php include('includes/header.php') ?>
<div class="content-wrapper">
<div class="container ">
<div class="row pad-botm">
<div class="col-md-12">
<h4 class="header-line text-center">Signup FORM</h4>
</div>
</div>
             
<!--LOGIN PANEL START-->           
<div class="row">
<div class="col-md-2 col-sm-2 col-xs-0 col-md-offset-2" ></div>
<div class="col-md-8 col-sm-8 col-xs-12 col-md-offset-1" >
<div class="panel panel-info">
<div class="panel-heading">
</div>
<div class="panel-body">
<form name="signup" method="post" onSubmit="return valid();"  enctype="multipart/form-data">
<div class="col-md-12 col-sm-12 col-md-offset-3 text-center" >
    <img src="logo.jpeg" >
</div>

<div class="form-group">
<label>Enter Full Name</label>
<input class="form-control" type="text" name="fullanme" autocomplete="off" required />
</div>


<div class="form-group">
<label>Mobile Number :</label>
<input class="form-control" type="text" name="mobileno" maxlength="10" autocomplete="off" required />
</div>
                                        
<div class="form-group">
<label>Enter Email</label>
<input class="form-control" type="email" name="email" id="emailid"  autocomplete="off" required  />
   <span id="user-availability-status" style="font-size:12px;"></span> 
</div>

<div class="form-group">
<label>Enter Password</label>
<input class="form-control" type="password" name="password" autocomplete="off" required  />
</div>

<div class="form-group">
<label>Confirm Password </label>
<input class="form-control"  type="password" name="confirmpassword" autocomplete="off" required  />
</div>
<div class="form-group">
    <label for="uimage">Your Image:</label>
    <input class="form-control" type="file" name="uimage" autocomplete="off" required />
    <span class = "error">* <?php echo htmlentities($_SESSION['rerror']);?></span>
</div>

<!-- Group of material radios - option 1 -->
<div class="form-check">
  <input type="radio" class="form-check-input"  value="1"  id="materialGroupExample1" name="rfeature">
  <label class="form-check-label" for="materialGroupExample1">Do you want Room</label>
</div>
<br>
<!-- Group of material radios - option 2 -->
<div class="form-check">
  <input type="radio" class="form-check-input" value="2" id="materialGroupExample2" name="rfeature">
  <label class="form-check-label" for="materialGroupExample2">Do you have Room</label>
</div>
<br>
<div class="text-center">
<button type="submit" name="signup" class="btn btn-danger rounded-circle mx-auto" id="submit">Register Now </button>
</div>
</form>
 </div>
</div>
</div>
</div>  
<!---LOGIN PABNEL END-->            
             
 
    </div>
    <br>
    <?php include('includes/footer2.php'); ?>
     <?php include('includes/footer.php'); ?>

    </div>


</body>
</html>